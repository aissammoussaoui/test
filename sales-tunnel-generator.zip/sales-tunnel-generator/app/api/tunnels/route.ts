import { NextResponse } from 'next/server'
import { connectToDatabase } from '@/lib/mongodb'
import { getServerSession } from "next-auth/next"
import { authOptions } from "../auth/[...nextauth]/route"

export async function POST(req: Request) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { title, description, price, imageUrl } = await req.json()
    const { db } = await connectToDatabase()

    const result = await db.collection('tunnels').insertOne({
      userId: session.user?.id,
      title,
      description,
      price,
      imageUrl,
      createdAt: new Date(),
      updatedAt: new Date(),
    })

    return NextResponse.json({ message: 'Tunnel created successfully', tunnelId: result.insertedId }, { status: 201 })
  } catch (error) {
    console.error('Tunnel creation error:', error)
    return NextResponse.json({ error: 'An error occurred while creating the tunnel' }, { status: 500 })
  }
}

export async function GET(req: Request) {
  try {
    const session = await getServerSession(authOptions)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { db } = await connectToDatabase()

    const tunnels = await db.collection('tunnels')
      .find({ userId: session.user?.id })
      .sort({ createdAt: -1 })
      .toArray()

    return NextResponse.json(tunnels)
  } catch (error) {
    console.error('Error fetching tunnels:', error)
    return NextResponse.json({ error: 'An error occurred while fetching tunnels' }, { status: 500 })
  }
}

