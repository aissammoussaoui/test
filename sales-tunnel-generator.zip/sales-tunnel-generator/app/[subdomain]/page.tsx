import { connectToDatabase } from '@/lib/mongodb'
import { ObjectId } from 'mongodb'
import { notFound } from 'next/navigation'

async function getTunnel(subdomain: string) {
  const { db } = await connectToDatabase()
  return db.collection('tunnels').findOne({ _id: new ObjectId(subdomain) })
}

export default async function TunnelPage({ params }: { params: { subdomain: string } }) {
  const tunnel = await getTunnel(params.subdomain)

  if (!tunnel) {
    notFound()
  }

  return (
    <div className="min-h-screen bg-gray-100 py-6 flex flex-col justify-center sm:py-12">
      <div className="relative py-3 sm:max-w-xl sm:mx-auto">
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-light-blue-500 shadow-lg transform -skew-y-6 sm:skew-y-0 sm:-rotate-6 sm:rounded-3xl"></div>
        <div className="relative px-4 py-10 bg-white shadow-lg sm:rounded-3xl sm:p-20">
          <div className="max-w-md mx-auto">
            <div>
              <img src={tunnel.imageUrl} alt={tunnel.title} className="w-full h-64 object-cover rounded-lg" />
              <h1 className="text-2xl font-semibold mt-4">{tunnel.title}</h1>
              <p className="text-gray-600 mt-2">{tunnel.description}</p>
              <p className="text-xl font-bold mt-4">${tunnel.price}</p>
            </div>
            <form className="mt-8 space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                  Full Name
                </label>
                <input
                  type="text"
                  name="name"
                  id="name"
                  required
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                />
              </div>
              <div>
                <label htmlFor="address" className="block text-sm font-medium text-gray-700">
                  Address
                </label>
                <input
                  type="text"
                  name="address"
                  id="address"
                  required
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                />
              </div>
              <div>
                <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                  Phone Number
                </label>
                <input
                  type="tel"
                  name="phone"
                  id="phone"
                  required
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                />
              </div>
              <div>
                <button
                  type="submit"
                  className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                >
                  Place Order (Cash on Delivery)
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}

