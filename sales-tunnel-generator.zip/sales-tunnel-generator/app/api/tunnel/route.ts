import { NextResponse } from 'next/server'
import { connectToDatabase } from '@/lib/mongodb'
import { ObjectId } from 'mongodb'

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const subdomain = searchParams.get('subdomain')

  if (!subdomain) {
    return NextResponse.json({ error: 'Subdomain not provided' }, { status: 400 })
  }

  try {
    const { db } = await connectToDatabase()
    const tunnel = await db.collection('tunnels').findOne({ _id: new ObjectId(subdomain) })

    if (!tunnel) {
      return NextResponse.json({ error: 'Tunnel not found' }, { status: 404 })
    }

    // Here, you would typically render your tunnel page with the tunnel data
    // For simplicity, we're just returning the tunnel data as JSON
    return NextResponse.json(tunnel)
  } catch (error) {
    console.error('Error fetching tunnel:', error)
    return NextResponse.json({ error: 'An error occurred while fetching the tunnel' }, { status: 500 })
  }
}

